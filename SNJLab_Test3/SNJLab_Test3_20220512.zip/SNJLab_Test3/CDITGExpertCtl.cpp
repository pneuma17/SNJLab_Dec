// CDITGExpertCtl.cpp  : Definition of ActiveX Control wrapper class(es) created by Microsoft Visual C++


#include "stdafx.h"
#include "CDITGExpertCtl.h"

/////////////////////////////////////////////////////////////////////////////
// CDITGExpertCtl

IMPLEMENT_DYNCREATE(CDITGExpertCtl, CWnd)

// CDITGExpertCtl properties

// CDITGExpertCtl operations
